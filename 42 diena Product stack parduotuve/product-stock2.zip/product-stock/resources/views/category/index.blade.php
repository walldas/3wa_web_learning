@extends('layouts.app')



@section('content')

    <h2>Kategorijų sąrašas</h2>



    <ul>

    @foreach ($categories as $category)
		<li>
            <a href="{{ route('categories.show', ['id' => $category->id]) }}">
                {{ $category->title }}
            </a>
              
		<a href="{{route('categories.edit',$category->id)}}" class="btn btn-primary">EDIT</a>

      	</li>

    @endforeach
 <a class="btn btn-primary btn-lg" href="{{route('categories.create')}}" role="button">Insert Category</a>
    </ul>

@endsection