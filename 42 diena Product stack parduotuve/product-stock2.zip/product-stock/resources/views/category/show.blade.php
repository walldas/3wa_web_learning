@extends('layouts.app')

@section('content')

<h2>Pagal kategorijas</h2>
<h2>Produktu sarasas:</h2>



<a href="http://localhost:8000/categories"   class="btn btn-success">back</a>

 <div class="row">
	@foreach ($category->products as $product)
	<div class="col-sm-6 col-md-4">
	<div class="thumbnail">
	<img src="{{ $product->image_url }}" alt="{{ $product->title }}">
		
		<h3>{{$product->title}}</h3>
		<p>{{$product->description}}</p>
		<p>Kaina:{{$product->price}}€</p>
		<p>Kiekis:{{$product->quantity}}vnt.</p>
		
		

				@if ($product->manufacturer)
                  <strong>Kategorija:</strong> {{ $product->category->title }}
                      <br />
                      <strong>Gamintojas:</strong> {{ $product->manufacturer->title }}
                      <br />
                      <strong>Remejai:</strong> {{ $product->supplier->title }}
                  @endif


<a class="btn btn-primary" href="{{ route('products.show', ['id' => $product->id]) }}">Peržiūrėti</a>
			 </div>
          </div>
        </div>
	
	@endforeach



@endsection