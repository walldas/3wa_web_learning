@extends('layouts.app')

@section('content')

	<h2>Gamintoju sarasas:</h2>
		<table>
	@foreach ($manufacturers as $vendor)
		<tr>
		<td>{{$vendor->title}}</td>
		<td>{{$vendor->website_url}}</td>
		
		</tr>
	@endforeach
	</table>
@endsection