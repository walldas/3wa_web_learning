@extends('layouts.app')

@section('content')

	<h2>Kategoriju sarasas</h2>
		<ul>
	@foreach ($list as $category)
		<li>{{$category->title}} 
		
		</li>

	@endforeach
	</ul>
@endsection
