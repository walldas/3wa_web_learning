@extends('layouts.app')

@section('content')
    <h2>Produktų sąrašas</h2>

    <div class="row">
    @foreach ($items as $product)
        <div class="col-sm-6 col-md-4">
          <div class="thumbnail">
            <img src="storage/{{ $product->image_url }}" alt="{{ $product->title }}">
            <div class="caption">
              <h3>{{ $product->title }}</h3>
              <p>{{ $product->description }}</p>
              <p>
                  Kaina: {{ $product->price }}€
                  Kiekis: {{ $product->quantity }}vnt.
              </p>
              <p>


                  @if ($product->manufacturer)
                  <strong>Kategorija:</strong> {{ $product->category->title }}
                      <br />
                      <strong>Gamintojas:</strong> {{ $product->manufacturer->title }}
                      <br />
                  <strong>Remejai:</strong> {{ $product->supplier->title }}
                  @endif
              </p>
              @if (Auth::check())
              <a class="btn btn-primary" href="{{ route('products.show', ['id' => $product->id]) }}">Peržiūrėti</a>
              @endif
            </div>
          </div>
        </div>
    @endforeach
    </div>
@endsection