@extends('layouts.app')



@section('content')

    <h2>Remeju sąrašas</h2>



    <ul>

    @foreach ($suppliers as $supplier)
		<li>
            <a href="{{ route('suppliers.show', ['id' => $supplier->id]) }}">
                {{ $supplier->title }}
            </a>
              
		<a href="{{route('suppliers.edit',$supplier->id)}}" class="btn btn-primary">EDIT</a>

      	</li>

    @endforeach
 <a class="btn btn-primary btn-lg" href="{{route('suppliers.create')}}" role="button">Insert Supplier</a>
    </ul>

@endsection