@extends('layouts.app')

@section('content')


<h2>Remeju kurimas (suppliers) kurimas:</h2>



 @if(isset($supplier))
	 {!! Form::model($supplier,[
	 'route' => ['suppliers.update',$supplier->id],
	 'method' =>'put']) !!}
 @else
{!! Form::open(['route' => 'suppliers.store','method' =>'post']) !!}

@endif




<div class="form-group">
	{!!Form::text('title',null,['class'=>"form-control",'placeholder'=>'Title'])!!}
</div>


{!!Form::submit('save',['class'=>'btn btn-primary'])!!}
{!! Form::close() !!}


@if(isset($supplier))
 {!! Form::open([
   'route'=>['suppliers.destroy', $supplier->id],
   'method' => 'delete']) !!}  
   {!! Form::submit('Delete', ['class' => 'btn btn-danger']) !!}
   @endif
@endsection