

@extends('layouts.app')

@section('content')



<h2>produkto sukurimas</h2>


 @if(isset($product))
	 {!! Form::model($product,[
	 'route' => ['products.update',$product->id],
	 'method' =>'put',
	 'files'=>true]) !!}
 @else
{!! Form::open(['route' => 'products.store','method' =>'post','files'=>true]) !!}

@endif

<div class="form-group">
	{!!Form::text('title',null,['class'=>"form-control",'placeholder'=>'Title'])!!}
</div>
<div class="form-group">
	{!!Form::number('price',null,['class'=>"form-control",'placeholder'=>'Price'])!!}
</div>
<div class="form-group">
	{!!Form::number('quantity',null,['class'=>"form-control",'placeholder'=>'quantity'])!!}
</div>


<div class="form-group">
	{!!Form::textarea('description',null,['class'=>"form-control",'placeholder'=>'description','row'=>'5'])!!}
</div>

<div class="form-group">
		{!! Form::select('category_id',$categories,null,['class'=>"form-control"])!!}
</div>
<div class="form-group">
		{!! Form::select('supplier_id',$suppliers,null,['class'=>"form-control"])!!}
</div>
<div class="form-group">
		{!! Form::select('manufacturer_id',$manufacturies,null,['class'=>"form-control"])!!}
</div>
<div class="form-group">
	{!!Form::file('image_url',null)!!}
</div>


{!!Form::submit('save',['class'=>'btn btn-primary'])!!}


{!! Form::close() !!}

@if(isset($product))
	{!!Form::open([
		'route'=>['products.destroy',$product->id],
		'method'=>'delete'
	])
	!!}

	{!!Form::submit("Delete",['class'=>"btn btn-danger"])!!}

@endif



@endsection