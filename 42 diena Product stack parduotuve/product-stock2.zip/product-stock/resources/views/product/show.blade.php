@extends('layouts.app')

@section('content')


<h1>{{$product->title}}</h1>


<img src="/storage/{{$product->image_url}}" class="img-responsive">

<p> <strong>{{$product->description}} </strong></p>


<ul>
	<li>kaina: {{$product->price}}E</li>
	<li>Kiekis: {{$product->quantity}} vnt.</li>
	<li>kategorija: {{$product->category->title}}</li>
	<li>gamintojai: {{$product->manufacturer->title}}</li>
	<li>rrremejai: {{$product->supplier->title}}</li>
	
@if (Auth::check())
<a href="{{route('products.edit',$product->id)}}" class="btn btn-primary">EDIT</a>
@endif
</ul>






@endsection