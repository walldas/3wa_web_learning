@extends('layouts.app')

@section('content')
    <p>Siandienos data: {{$date}}</p>
@endsection

