<?php $__env->startSection('content'); ?>


<h1><?php echo e($product->title); ?></h1>


<img src="/storage/<?php echo e($product->image_url); ?>" class="img-responsive">

<p> <strong><?php echo e($product->description); ?> </strong></p>


<ul>
	<li>kaina: <?php echo e($product->price); ?>E</li>
	<li>Kiekis: <?php echo e($product->quantity); ?> vnt.</li>
	<li>kategorija: <?php echo e($product->category->title); ?></li>
	<li>gamintojai: <?php echo e($product->manufacturer->title); ?></li>
	<li>rrremejai: <?php echo e($product->supplier->title); ?></li>
	
<?php if(Auth::check()): ?>
<a href="<?php echo e(route('products.edit',$product->id)); ?>" class="btn btn-primary">EDIT</a>
<?php endif; ?>
</ul>






<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>