<?php $__env->startSection('content'); ?>

<h2>Pagal kategorijas</h2>
<h2>Produktu sarasas:</h2>



<a href="http://localhost:8000/categories"   class="btn btn-success">back</a>

 <div class="row">
	<?php $__currentLoopData = $category->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<div class="col-sm-6 col-md-4">
	<div class="thumbnail">
	<img src="<?php echo e($product->image_url); ?>" alt="<?php echo e($product->title); ?>">
		
		<h3><?php echo e($product->title); ?></h3>
		<p><?php echo e($product->description); ?></p>
		<p>Kaina:<?php echo e($product->price); ?>€</p>
		<p>Kiekis:<?php echo e($product->quantity); ?>vnt.</p>
		
		

				<?php if($product->manufacturer): ?>
                  <strong>Kategorija:</strong> <?php echo e($product->category->title); ?>

                      <br />
                      <strong>Gamintojas:</strong> <?php echo e($product->manufacturer->title); ?>

                      <br />
                      <strong>Remejai:</strong> <?php echo e($product->supplier->title); ?>

                  <?php endif; ?>


<a class="btn btn-primary" href="<?php echo e(route('products.show', ['id' => $product->id])); ?>">Peržiūrėti</a>
			 </div>
          </div>
        </div>
	
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>