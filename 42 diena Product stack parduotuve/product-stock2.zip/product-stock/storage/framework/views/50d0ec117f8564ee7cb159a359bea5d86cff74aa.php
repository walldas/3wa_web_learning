<?php $__env->startSection('content'); ?>


<h2>kategorijos kurimas:</h2>



 <?php if(isset($category)): ?>
	 <?php echo Form::model($category,[
	 'route' => ['categories.update',$category->id],
	 'method' =>'put']); ?>

 <?php else: ?>
<?php echo Form::open(['route' => 'categories.store','method' =>'post']); ?>


<?php endif; ?>




<div class="form-group">
	<?php echo Form::text('title',null,['class'=>"form-control",'placeholder'=>'Title']); ?>

</div>


<?php echo Form::submit('save',['class'=>'btn btn-primary']); ?>

<?php echo Form::close(); ?>



<?php if(isset($category)): ?>
 <?php echo Form::open([
   'route'=>['categories.destroy', $category->id],
   'method' => 'delete']); ?>  
   <?php echo Form::submit('Delete', ['class' => 'btn btn-danger']); ?>

   <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>