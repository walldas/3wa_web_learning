<?php $__env->startSection('content'); ?>



<h2>produkto sukurimas</h2>


 <?php if(isset($product)): ?>
	 <?php echo Form::model($product,[
	 'route' => ['products.update',$product->id],
	 'method' =>'put',
	 'files'=>true]); ?>

 <?php else: ?>
<?php echo Form::open(['route' => 'products.store','method' =>'post','files'=>true]); ?>


<?php endif; ?>

<div class="form-group">
	<?php echo Form::text('title',null,['class'=>"form-control",'placeholder'=>'Title']); ?>

</div>
<div class="form-group">
	<?php echo Form::number('price',null,['class'=>"form-control",'placeholder'=>'Price']); ?>

</div>
<div class="form-group">
	<?php echo Form::number('quantity',null,['class'=>"form-control",'placeholder'=>'quantity']); ?>

</div>


<div class="form-group">
	<?php echo Form::textarea('description',null,['class'=>"form-control",'placeholder'=>'description','row'=>'5']); ?>

</div>

<div class="form-group">
		<?php echo Form::select('category_id',$categories,null,['class'=>"form-control"]); ?>

</div>
<div class="form-group">
		<?php echo Form::select('supplier_id',$suppliers,null,['class'=>"form-control"]); ?>

</div>
<div class="form-group">
		<?php echo Form::select('manufacturer_id',$manufacturies,null,['class'=>"form-control"]); ?>

</div>
<div class="form-group">
	<?php echo Form::file('image_url',null); ?>

</div>


<?php echo Form::submit('save',['class'=>'btn btn-primary']); ?>



<?php echo Form::close(); ?>


<?php if(isset($product)): ?>
	<?php echo Form::open([
		'route'=>['products.destroy',$product->id],
		'method'=>'delete'
	]); ?>


	<?php echo Form::submit("Delete",['class'=>"btn btn-danger"]); ?>


<?php endif; ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>