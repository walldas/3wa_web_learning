<?php $__env->startSection('content'); ?>

    <h2>Kategorijų sąrašas</h2>



    <ul>

    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<li>
            <a href="<?php echo e(route('categories.show', ['id' => $category->id])); ?>">
                <?php echo e($category->title); ?>

            </a>
              
		<a href="<?php echo e(route('categories.edit',$category->id)); ?>" class="btn btn-primary">EDIT</a>

      	</li>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 <a class="btn btn-primary btn-lg" href="<?php echo e(route('categories.create')); ?>" role="button">Insert Category</a>
    </ul>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>