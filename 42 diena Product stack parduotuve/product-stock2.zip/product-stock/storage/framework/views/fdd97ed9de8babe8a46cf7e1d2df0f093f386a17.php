<?php $__env->startSection('content'); ?>


<h2>Remeju kurimas (suppliers) kurimas:</h2>



 <?php if(isset($supplier)): ?>
	 <?php echo Form::model($supplier,[
	 'route' => ['suppliers.update',$supplier->id],
	 'method' =>'put']); ?>

 <?php else: ?>
<?php echo Form::open(['route' => 'suppliers.store','method' =>'post']); ?>


<?php endif; ?>




<div class="form-group">
	<?php echo Form::text('title',null,['class'=>"form-control",'placeholder'=>'Title']); ?>

</div>


<?php echo Form::submit('save',['class'=>'btn btn-primary']); ?>

<?php echo Form::close(); ?>



<?php if(isset($supplier)): ?>
 <?php echo Form::open([
   'route'=>['suppliers.destroy', $supplier->id],
   'method' => 'delete']); ?>  
   <?php echo Form::submit('Delete', ['class' => 'btn btn-danger']); ?>

   <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>