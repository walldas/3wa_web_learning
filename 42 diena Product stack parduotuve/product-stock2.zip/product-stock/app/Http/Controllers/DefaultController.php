<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Category;
use App\Product;
use App\Supplier;
use App\Manufacturer;

class DefaultController extends Controller
{
    public function today(){
    	$date=new \DateTime();
    	return view('date',['date'=>$date->format("Y-m-d")]);
    }
    public function name($name="3wa"){
    	 return "mano vardas: ".ucfirst($name);
    }
    public function categories(){
    	$categories=Category::all();
    	return view('categories',['list'=>$categories]);
    }
    public function products(){
    	$products=Product::all();
    	return view('products',['items'=>$products]);
    }
    public function vendors(){
    	$vendors=Manufacturer::all();
    	return view('vendors',['manufacturers'=>$vendors]);
    }
    public function suppliers(){
        $suppliers=Suppliers::all();
        return view('suppliers',['list'=>$suppliers]);
    }

}
