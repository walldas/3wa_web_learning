INSTRUCTIONS
* Review of float and inline-block

HTML
* Use normalize.css

CSS
* Use inline-block and float to place some elements
* Width limited to 1500px max
* Header block transparency : 0.75
* Use a '.container' class to limit the content

Font size:
Default root font size: 14px

default body font size: 1rem
h1 titles: 3rem
h2 titles: 2rem

Fonts used:
Title: "Courgette"
Text: "Open Sans"

BONUS
Find how to embed a google map


=== COLORS ===
Green color: #49C3B4
Dark yellow color: #B7B12E